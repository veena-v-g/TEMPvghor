import re
import csv
import random

def convert_file(filename):
    altered_filename = filename.split('.',1)[0]
    altered_filename += ('.csv')
    read_file = open(filename,'r')
    with open(altered_filename, 'w') as write_file:
        file_writer = csv.writer(write_file)
        for line in read_file:
            clean_line = line.strip()
            file_writer.writerow([clean_line])
    read_file.close()
    write_file.close()
    return altered_filename

def create_genome(filename):
    count = 1
    altered_filename = ('karyotype.combined.txt')
    opened_filename = open(filename, 'r')
    write_filename = open(altered_filename, 'w')
    w_1 = open("combined.highlights.3.txt", 'w')
    w_2 = open("combined.highlights.4.txt", 'w')
    w_3 = open("combined.highlights.5.txt", 'w')
    w_4 = open("combined.highlights.6.txt", 'w')
    w_5 = open("combined.highlights.7.txt", 'w')
    w_6 = open("combined.highlights.8.txt", 'w')
    read = csv.reader(opened_filename)
    write_filename.write('chr - chr1 1 0 8674854 black\n')
    for row in read:
        line = row[0]
        if "Location" not in line and "protein" not in line and 'd7ajXo3bMQ' not in line:
            line2 = line.split("\t", 1)[0]
            start = line2.split("..",1)[0]
            end = line2.split("..",1)[-1]
            one = 1
            two = 1
            three = 1
            four = 1
            five = 1
            six = 1
            if count % 6 == 0:
                w_6.write("chr1 "+start+" "+end+" "+"fill_color=chr"+str(random.randint(1,21))+"\n")
                count += 1
                six += 1
            if count % 6 == 1:
                w_1.write("chr1 "+start+" "+end+" "+"fill_color=chr"+str(random.randint(1,21))+"\n")
                count += 1
                one += 1
            if count % 6 == 2:
                w_2.write("chr1 "+start+" "+end+" "+"fill_color=chr"+str(random.randint(1,21))+"\n")
                count += 1
                two += 1
            if count % 6 == 3:
                w_3.write("chr1 "+start+" "+end+" "+"fill_color=chr"+str(random.randint(1,21))+"\n")
                count += 1
                three += 1
            if count % 6 == 4:
                w_4.write("chr1 "+start+" "+end+" "+"fill_color=chr"+str(random.randint(1,21))+"\n")
                count += 1
                four += 1
            if count % 6 == 5:
                w_5.write("chr1 "+start+" "+end+" "+"fill_color=chr"+str(random.randint(1,21))+"\n")
                count += 1
                five += 1
            #written_filename.write("chr1 "+start+" "+end+" "+"fill_color=chr"+str(random.randint(1,21))+"\n")
    opened_filename.close()
    write_filename.close()
    w_1.close()
    w_2.close()
    w_3.close()
    w_4.close()
    w_5.close()
    w_6.close()
    return altered_filename

def find_phage_start(line):
    if 'complement' in line:
        line = line[line.find("(")+1:line.find(")")]
        line = line.split('..',1)[0]
    if '[' in line:
        keyword = '                   '
        before, keyword, after = line.partition(keyword)
        line = before[2:]
        line = line.split('..',1)[0]
    return line

def find_phage_end(line):
    if 'complement' in line:
        line = line[line.find("(")+1:line.find(")")]
        line = line.split('..',1)[-1]
    if '[' in line:
        keyword = '                   '
        before, keyword, after = line.partition(keyword)
        line = before
        line = line.split('..',1)[-1]
    return line

def find_gene_label(line, end):
    gene_label = line.split(end)[1]
    gene_label = gene_label.split('N/A')[0]
    gene_label = gene_label.split('e-0')[0]
    gene_label = gene_label.split('e-1')[0]
    gene_label = gene_label.split('e-2')[0]
    gene_label = gene_label.split('e-3')[0]
    gene_label = gene_label.split('0.0')[0]
    if '(' in line:
        gene_label = gene_label[1:]
    gene_label = gene_label[:-1]
    gene_label = gene_label.strip()
    gene_label = gene_label.split(':')[0]
    gene_label = gene_label.split(';')[0]
    if 'protein ' in gene_label:
        gene_label = gene_label.split('protein ')[-1]
        gene_label = gene_label.split(' [')[0]
    if 'ref' in gene_label:
        gene_label = gene_label.split('|ref|')[-1]
        gene_label = gene_label[:-1]
    return str(gene_label)

def write_phage_regions(filename):
    altered_filename = filename.split('.',1)[0]
    altered_filename += ('.phage.txt')
    written_filename = open('clean_labels.txt', 'w')
    opened_filename = open(filename, 'r')
    write_filename = open(altered_filename, 'w')
    read = csv.reader(opened_filename)
    i = 1
    for row in read:
            line = str(row)
            if 'region' in line:
                line = "change color"
            if '----' not in line and 'region' not in line and 'Genome' not in line and 'CDS' not in line and line != ' ' and line !='  []' and line !="\n":
                start = find_phage_start(line)
                end = find_phage_end(line)
                gene_label = find_gene_label(line, end)
                write_filename.write("chr"+str(i)+" "+start+" "+end+" "+str(i)+"\n")
                written_filename.write("chr1"+" "+start+" "+end+" "+gene_label+"\n")
                i+=1
            if line == '\n':
                pass
            else:
                pass
    opened_filename.close()
    write_filename.close()
    written_filename.close()
    create_phage_labels()
    return altered_filename

def write_ta_pairs(filename):
    altered_filename = ('combined.labels.txt')
    opened_filename = open(filename, 'r')
    write_filename = open(altered_filename, 'w')
    written_filename = open('combined.highlights.1.txt','w')
    read = csv.reader(opened_filename)
    fill_color = "no color"
    for row in read:
        line = row[0]
        if '*' in line or '#' in line or "Location" in line:
            continue
        else:
            line2 = line.split("\t", 1)[0]
            gene_label = line.split("\t")[2]
            start = line2.split("..",1)[0]
            end = line2.split("..",1)[-1]
            write_filename.write("chr1"+" "+start+" "+end+" "+gene_label+"\n")
            written_filename.write("chr1"+" "+start+" "+end+" "+"fill_color=chr"+str(random.randint(1,21))+"\n")
    opened_filename.close()
    write_filename.close()
    written_filename.close()
    return altered_filename

def create_phage_labels():
    read_filename = open('clean_labels.txt', 'r')
    write_filename = open('combined.labels.2.txt','w')
    for row in read_filename:
        if '[]' not in row and 'change color' not in row:
            write_filename.write(row)
        else:
            pass
    write_filename.close()
    read_filename.close()

def create_highlight_item(filename):
    write_filename = open('combined.highlights.2.txt', 'w')
    read = open(filename, 'r')
    int = random.randint(1,21)
    fill_color = "fill_color=chr"+str(int)
    count = 0
    for row in read:
        if "change color" in row:
            count += 1
            int = count * 5
            if (int % 2 == 0):
                int = random.randint(7,21)
            fill_color = "fill_color=chr"+str(int)
            pass
        if '[]' not in row and "change color" not in row:
            row = row.split(" ")
            row[0] = "chr1"
            row[-1] = fill_color
            row = " ".join(row)
            write_filename.write(row+"\n")
    write_filename.close()
    read.close()

def main():
    filename = convert_file('combined.txt')
    combined_genome = create_genome(filename)
    create_ta_pairs = convert_file('combined_ta_pairs.txt')
    create_ta_file = write_ta_pairs(create_ta_pairs)
    prophage_csv = convert_file('combined_phage.txt')
    create_prophage_file = write_phage_regions(prophage_csv)
    highlight_file = create_highlight_item(create_prophage_file)

main()
